<?Php
echo $_POST['Category'];
echo "<br>";
echo $_POST['SubCat'];
?>
